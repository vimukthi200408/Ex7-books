﻿using System;
namespace ex7books
{
    public class Author
    {
        private string name;
        private string email;

        public Author()
        {

        }

        public Author(string name, string email)
        {
            this.name = name;
            this.email = email;
        }

        public string getName()
        {
            return name;
        }

        public string getEmail()
        {
            return email;
        }

        public void setEmail(string email)
        {
            this.email = email;
        }
        //to string
        public String ToString()
        {
            return "Author[name = " + name + ", " + "email = " + email + "]";

        }
    }
}

