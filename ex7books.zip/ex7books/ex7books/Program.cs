﻿namespace ex7bboks
{
    class Program
    {
        static void Main(string[] args)
        {

        }
    }
}